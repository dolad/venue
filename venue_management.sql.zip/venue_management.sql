-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 06, 2017 at 05:58 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `venue_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_tb`
--

CREATE TABLE `admin_tb` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(30) NOT NULL,
  `admin_pass` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_tb`
--

INSERT INTO `admin_tb` (`admin_id`, `admin_name`, `admin_pass`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `course_alloc_tb`
--

CREATE TABLE `course_alloc_tb` (
  `alloc_id` int(30) NOT NULL,
  `period_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `dept_id` int(11) NOT NULL,
  `venue_id` int(11) NOT NULL,
  `days_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_alloc_tb`
--

INSERT INTO `course_alloc_tb` (`alloc_id`, `period_id`, `staff_id`, `course_id`, `dept_id`, `venue_id`, `days_id`) VALUES
(1, 2, 7, 10, 7, 1, 2),
(2, 4, 7, 11, 7, 1, 2),
(3, 2, 7, 10, 7, 1, 4),
(4, 2, 1, 7, 1, 1, 1),
(5, 2, 1, 9, 1, 2, 3),
(6, 2, 1, 8, 1, 2, 5),
(7, 5, 1, 7, 1, 2, 2),
(8, 5, 1, 7, 1, 2, 4),
(9, 6, 1, 6, 1, 2, 1),
(10, 2, 7, 10, 7, 3, 6),
(11, 4, 7, 11, 7, 3, 3),
(12, 2, 7, 12, 7, 3, 3),
(13, 2, 7, 10, 7, 3, 1),
(14, 4, 7, 12, 7, 3, 1),
(15, 4, 7, 11, 7, 3, 6),
(16, 2, 7, 10, 7, 3, 7);

-- --------------------------------------------------------

--
-- Table structure for table `course_tb`
--

CREATE TABLE `course_tb` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(20) NOT NULL,
  `dept_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_tb`
--

INSERT INTO `course_tb` (`course_id`, `course_name`, `dept_id`) VALUES
(6, 'CSE101', 1),
(7, 'CSE102', 1),
(8, 'MTH101', 1),
(9, 'MTH102', 1),
(10, 'CHM101', 7),
(11, 'CHM102', 7),
(12, 'CHM191', 7),
(13, 'SSS 301', 12),
(14, 'PHY494', 10),
(15, 'EEE201', 4),
(16, 'PHY999', 10),
(17, 'PH777', 10);

-- --------------------------------------------------------

--
-- Table structure for table `days_tb`
--

CREATE TABLE `days_tb` (
  `days_id` int(30) NOT NULL,
  `day` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `days_tb`
--

INSERT INTO `days_tb` (`days_id`, `day`) VALUES
(1, 'MONDAY'),
(2, 'TUESDAY'),
(3, 'WEDNESDAY'),
(4, 'THURSDAY'),
(5, 'FRIDAY'),
(6, 'SATURDAY'),
(7, 'SUNDAY');

-- --------------------------------------------------------

--
-- Table structure for table `department_tb`
--

CREATE TABLE `department_tb` (
  `dept_id` int(11) NOT NULL,
  `dept_name` varchar(30) NOT NULL,
  `faculty_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department_tb`
--

INSERT INTO `department_tb` (`dept_id`, `dept_name`, `faculty_id`) VALUES
(1, 'COMPUTER SCI AND ENG.', 1),
(2, 'MECH ENGINEERING', 1),
(3, 'CHEMICAL ENGINEERING', 1),
(4, 'ELECT. ENGINEERING', 1),
(5, 'AGRIC. ENGINEERING', 1),
(6, 'CIVIL ENGINEERING', 1),
(7, 'CHEMISTRY', 2),
(8, 'PHYSICS', 2),
(9, 'BIOLOGY', 2),
(10, 'PHYSIOLOGY', 5),
(11, 'New building', 5),
(12, 'MATHEMATICS', 3),
(13, 'METALLURGICAL ENGINEERING', 1),
(14, 'AGRIC ECONS', 3),
(15, 'ARCHITECTURE', 6);

-- --------------------------------------------------------

--
-- Table structure for table `faculty_tb`
--

CREATE TABLE `faculty_tb` (
  `faculty_id` int(11) NOT NULL,
  `faculty_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty_tb`
--

INSERT INTO `faculty_tb` (`faculty_id`, `faculty_name`) VALUES
(1, 'ENGINEERING AND TECHNOLOGY'),
(2, 'PURE AND APPLIED SCIENCES'),
(3, 'AGRICULTURAL SCIENCES'),
(4, 'MANAGEMENT SCIENCES'),
(5, 'FABAMSA'),
(6, 'ENVIRONMENTAL SCIENCES'),
(7, ''),
(8, 'ART'),
(9, 'LAW'),
(10, 'FACULTY SAMPLE');

-- --------------------------------------------------------

--
-- Table structure for table `level_tb`
--

CREATE TABLE `level_tb` (
  `level_id` int(11) NOT NULL,
  `level` varchar(30) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `level_tb`
--

INSERT INTO `level_tb` (`level_id`, `level`, `time`) VALUES
(1, '100L', '2017-10-04 00:45:57'),
(2, '200L', '2017-10-04 00:45:57'),
(3, '300L', '2017-10-04 00:45:57'),
(4, '400L', '2017-10-04 00:45:57'),
(5, '500L', '2017-10-04 00:45:57');

-- --------------------------------------------------------

--
-- Table structure for table `period_tb`
--

CREATE TABLE `period_tb` (
  `period_id` int(30) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `period_tb`
--

INSERT INTO `period_tb` (`period_id`, `start_time`, `end_time`) VALUES
(1, '08:00:00', '09:00:00'),
(2, '09:00:00', '10:00:00'),
(3, '10:00:00', '11:00:00'),
(4, '11:00:00', '00:00:00'),
(5, '00:00:00', '13:00:00'),
(6, '13:00:00', '14:00:00'),
(7, '14:00:00', '15:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `semester_tb`
--

CREATE TABLE `semester_tb` (
  `semester_id` int(11) NOT NULL,
  `semester` varchar(100) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `semester_tb`
--

INSERT INTO `semester_tb` (`semester_id`, `semester`, `time`) VALUES
(1, 'First Semester', '2017-10-04 14:52:20'),
(2, 'Second Semester', '2017-10-04 14:52:45');

-- --------------------------------------------------------

--
-- Table structure for table `staff_tb`
--

CREATE TABLE `staff_tb` (
  `staff_id` int(11) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL,
  `dept_id` int(11) NOT NULL,
  `staff_no` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff_tb`
--

INSERT INTO `staff_tb` (`staff_id`, `first_name`, `last_name`, `phone`, `email`, `status`, `dept_id`, `staff_no`) VALUES
(1, 'h', 'j', 'j', 'j@j.com', 'hod', 1, 'h'),
(3, 'j', 'j', 'j', 'l@k.com', 'hod', 8, 'sds'),
(4, 'Jinadu', 'Audu', '08099090980', 'jaudu@gmail.com', 'lecturer', 1, 'jj888j'),
(5, 'Fred', 'Oba', '090909', 'h@jj.com', 'hod', 8, '333'),
(6, 'Abraham', 'Jang', '09090', 'jk@jk.com', 'lecturer', 10, '3838'),
(7, 'Jonah', 'Joseph', '0907876544', 'jj@jk.com', 'lecturer', 7, '8989'),
(8, 'Bola', 'Agbe', '09098887', 'ba@gmail.com', 'hod', 12, 'jlkls'),
(9, 'Femi', 'Adam', '90', 'o@o.com', 'lecturer', 10, 'o'),
(10, 'm', 'm', '77', 'm@m.com', 'lecturer', 2, 'm');

-- --------------------------------------------------------

--
-- Table structure for table `student_tb`
--

CREATE TABLE `student_tb` (
  `student_id` int(11) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `matric_no` varchar(6) NOT NULL,
  `dept_id` int(11) NOT NULL,
  `gender` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `venue_tb`
--

CREATE TABLE `venue_tb` (
  `venue_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `image` varchar(200) NOT NULL,
  `latitude` varchar(30) NOT NULL,
  `longitude` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `venue_tb`
--

INSERT INTO `venue_tb` (`venue_id`, `name`, `image`, `latitude`, `longitude`) VALUES
(1, 'High Rise', 'High Rise-high rise.PNG', '8.1677648', '4.268928800000026'),
(2, 'MKO', 'MKO-MKO.PNG', '8.113615', '4.252396'),
(3, 'Real mko', 'Real mko-MKO-MKO.PNG', '8.1695997', '4.264398799999981');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_tb`
--
ALTER TABLE `admin_tb`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `admin_pass` (`admin_pass`);

--
-- Indexes for table `course_alloc_tb`
--
ALTER TABLE `course_alloc_tb`
  ADD PRIMARY KEY (`alloc_id`),
  ADD KEY `lecturer_id` (`staff_id`),
  ADD KEY `period_id` (`period_id`),
  ADD KEY `course_id` (`course_id`),
  ADD KEY `dept_id` (`dept_id`),
  ADD KEY `venue_id` (`venue_id`),
  ADD KEY `days_id` (`days_id`);

--
-- Indexes for table `course_tb`
--
ALTER TABLE `course_tb`
  ADD PRIMARY KEY (`course_id`),
  ADD KEY `dept_id` (`dept_id`);

--
-- Indexes for table `days_tb`
--
ALTER TABLE `days_tb`
  ADD PRIMARY KEY (`days_id`);

--
-- Indexes for table `department_tb`
--
ALTER TABLE `department_tb`
  ADD PRIMARY KEY (`dept_id`),
  ADD KEY `faculty_id` (`faculty_id`),
  ADD KEY `faculty_id_2` (`faculty_id`);

--
-- Indexes for table `faculty_tb`
--
ALTER TABLE `faculty_tb`
  ADD PRIMARY KEY (`faculty_id`);

--
-- Indexes for table `level_tb`
--
ALTER TABLE `level_tb`
  ADD PRIMARY KEY (`level_id`);

--
-- Indexes for table `period_tb`
--
ALTER TABLE `period_tb`
  ADD PRIMARY KEY (`period_id`);

--
-- Indexes for table `semester_tb`
--
ALTER TABLE `semester_tb`
  ADD PRIMARY KEY (`semester_id`);

--
-- Indexes for table `staff_tb`
--
ALTER TABLE `staff_tb`
  ADD PRIMARY KEY (`staff_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `dept_id` (`dept_id`);

--
-- Indexes for table `student_tb`
--
ALTER TABLE `student_tb`
  ADD PRIMARY KEY (`student_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `dept_id` (`dept_id`);

--
-- Indexes for table `venue_tb`
--
ALTER TABLE `venue_tb`
  ADD PRIMARY KEY (`venue_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_tb`
--
ALTER TABLE `admin_tb`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `course_alloc_tb`
--
ALTER TABLE `course_alloc_tb`
  MODIFY `alloc_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `course_tb`
--
ALTER TABLE `course_tb`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `days_tb`
--
ALTER TABLE `days_tb`
  MODIFY `days_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `department_tb`
--
ALTER TABLE `department_tb`
  MODIFY `dept_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `faculty_tb`
--
ALTER TABLE `faculty_tb`
  MODIFY `faculty_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `level_tb`
--
ALTER TABLE `level_tb`
  MODIFY `level_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `period_tb`
--
ALTER TABLE `period_tb`
  MODIFY `period_id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `semester_tb`
--
ALTER TABLE `semester_tb`
  MODIFY `semester_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `staff_tb`
--
ALTER TABLE `staff_tb`
  MODIFY `staff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `student_tb`
--
ALTER TABLE `student_tb`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `venue_tb`
--
ALTER TABLE `venue_tb`
  MODIFY `venue_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `course_alloc_tb`
--
ALTER TABLE `course_alloc_tb`
  ADD CONSTRAINT `course_alloc_tb_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `department_tb` (`dept_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `course_alloc_tb_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `course_tb` (`course_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `course_alloc_tb_ibfk_4` FOREIGN KEY (`period_id`) REFERENCES `period_tb` (`period_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `course_alloc_tb_ibfk_5` FOREIGN KEY (`venue_id`) REFERENCES `venue_tb` (`venue_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `course_alloc_tb_ibfk_6` FOREIGN KEY (`days_id`) REFERENCES `days_tb` (`days_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `course_alloc_tb_ibfk_7` FOREIGN KEY (`staff_id`) REFERENCES `staff_tb` (`staff_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `course_tb`
--
ALTER TABLE `course_tb`
  ADD CONSTRAINT `course_tb_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `department_tb` (`dept_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `department_tb`
--
ALTER TABLE `department_tb`
  ADD CONSTRAINT `department_tb_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `faculty_tb` (`faculty_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `staff_tb`
--
ALTER TABLE `staff_tb`
  ADD CONSTRAINT `staff_tb_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `department_tb` (`dept_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student_tb`
--
ALTER TABLE `student_tb`
  ADD CONSTRAINT `student_tb_ibfk_1` FOREIGN KEY (`dept_id`) REFERENCES `department_tb` (`dept_id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
